package aplicacao.renovacao;

import gerenciador_locacoes.Locacao;

public interface IEfetuarRenovacao {

	public boolean realizarRenovacao(Locacao Locac);

}
