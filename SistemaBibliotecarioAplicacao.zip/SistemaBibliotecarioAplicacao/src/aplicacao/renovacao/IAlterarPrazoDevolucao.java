package aplicacao.renovacao;

import gerenciador_locacoes.Locacao;

public interface IAlterarPrazoDevolucao {

	public boolean alterarPrazoDevolucao(Locacao Locac);

}
