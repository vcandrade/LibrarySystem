package aplicacao.reserva;

public interface IRealizarReserva {
	
	public boolean realizarReserva(Reserva Rev);

}
