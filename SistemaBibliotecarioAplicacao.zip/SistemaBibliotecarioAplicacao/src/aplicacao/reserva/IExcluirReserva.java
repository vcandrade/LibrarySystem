package aplicacao.reserva;

import java.util.List;

public interface IExcluirReserva {
	
	public boolean excluirReserva(Reserva Rev);
	public List<Reserva> listarReservas();

}
