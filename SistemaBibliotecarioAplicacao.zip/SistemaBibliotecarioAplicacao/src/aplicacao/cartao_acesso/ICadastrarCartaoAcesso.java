package aplicacao.cartao_acesso;

public interface ICadastrarCartaoAcesso {

	public boolean cadastrarCartao(CartaoAcesso Cart);
	
}
