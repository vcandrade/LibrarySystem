package gerenciador_exemplares;

import gerenciador_locatarios.Pessoa;

public class Autor extends Pessoa{

	String WebSite;

	public String getWebSite() {
		return WebSite;
	}

	public void setWebSite(String webSite) {
		WebSite = webSite;
	}
}
