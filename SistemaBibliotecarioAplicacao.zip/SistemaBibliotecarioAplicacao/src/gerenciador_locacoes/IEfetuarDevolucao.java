package gerenciador_locacoes;

public interface IEfetuarDevolucao {

	public boolean realizarDevolucao(Locacao Locac);

}
