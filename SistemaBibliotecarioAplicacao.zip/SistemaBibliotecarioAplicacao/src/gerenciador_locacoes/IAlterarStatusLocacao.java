package gerenciador_locacoes;

public interface IAlterarStatusLocacao {

	public boolean alterarStatusLocacao(Locacao Locac);

}
