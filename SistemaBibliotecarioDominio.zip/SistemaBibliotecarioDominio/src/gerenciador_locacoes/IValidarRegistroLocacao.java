package gerenciador_locacoes;

public interface IValidarRegistroLocacao {

	public boolean validarLocacao(Locacao Locac);

}
