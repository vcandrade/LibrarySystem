package gerenciador_locacoes;

public interface IEfetuarLocacao {

	public boolean realizarLocacao(Locacao Locac);

}
