package teste;

public enum Titulos {

	inicial("Inicial"), 
	inserirLocatario("Inserir Locat�rio"), 
	editarLocatario("Editar Locat�rio"),
	inserirExemplar("Inserir Exemplar"), 
	editarExemplar("Editar Exemplar"), 
	inserirLocacao("Inserir Loca��o");

	public String Titulo;

	Titulos(String Titulo) {
		this.Titulo = "UTBiblio - " + Titulo;
	}

}
